package bank;

public class SavingsAccount extends BankAccount{
	private double interestRate;
	public SavingsAccount(int accountNumber, double amount, double rate){ 
		super(accountNumber, amount);
	    rate = interestRate;
    }
 
    public void addInterest() throws Exception{ 
    	double interest = getBalance() * interestRate / 100;
        super.deposit(interest);
    }
}
