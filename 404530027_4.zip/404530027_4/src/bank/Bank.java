package bank;

import java.util.ArrayList;
import java.util.HashMap;

public class Bank {
	
	HashMap<Integer, BankAccount> BankList = new HashMap<Integer, BankAccount>();
	private ArrayList<BankAccount> accounts;
	public Bank()
	{
		accounts = new ArrayList<BankAccount>();
	}
	public void addAccount(int accountNumber, double balance) {
		if(balance < 0)
			balance = 0;
		BankList.put(accountNumber,new BankAccount(accountNumber, balance));
	}

	public void deposit(int accountNumber, double balance) {
		BankAccount tempAccount = (BankAccount) BankList.get(accountNumber);
		try{
			tempAccount.deposit(balance);
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
	}

	public void withdraw(int accountNumber, int balance) {
		BankAccount tempAccount = (BankAccount) BankList.get(accountNumber);
		try{
			tempAccount.withdraw(balance);
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
	
	double getBalance (int accountNumber){
		BankAccount tempAccount = (BankAccount) BankList.get(accountNumber);
		return tempAccount.getBalance();
	}

	public void closeAccount(int accountNumber) {
		BankAccount tempAccount = (BankAccount) BankList.get(accountNumber);
		tempAccount.close();
	}

	public void suspendAccount(int accountNumber) {
		BankAccount tempAccount = (BankAccount) BankList.get(accountNumber);
		tempAccount.suspend();
	}

	public void reOpenAccount(int accountNumber) {
		BankAccount tempAccount = (BankAccount) BankList.get(accountNumber);
		tempAccount.reOpen();
	}
	
	String getAccountStatus(int accountNumber){
		BankAccount tempAccount = (BankAccount) BankList.get(accountNumber);
		return tempAccount.state;
	}
	
	String summarizeAccountTransactions(int accountNumber){
		StringBuffer sb = new StringBuffer();
		BankAccount tempAccount = (BankAccount) BankList.get(accountNumber);
		sb.append("Account #" + accountNumber + "transaction�G\n\n");
		sb.append(tempAccount.getTransations());
		sb.append("End of transaction\n");
		return sb.toString();
	}
	
	String summarizeAllAccounts(){
		StringBuffer sb = new StringBuffer();
		sb.append("Account\tBalance\t#Transaction\tStatus\n");
		for(BankAccount bank : BankList.values()){
			sb.append(bank.accountNumber + "\t");
			sb.append(bank.getBalance() + "\t");
			sb.append(bank.retrieveNumberOfTransactions() + "\t\t");
			sb.append(bank.state + "\n");
		}
		sb.append("End of Account Summary\n");
		return sb.toString();
	}
	
}
