package bank;

public class CheckingAccount {
	private double withdrawals;
	
	public CheckingAccount(int accountNumber, double initialBalance){
		
		super();
		setwithdrawals(withdrawals);
		}
		       
		public void setwithdrawals(double o) {
			withdrawals = o;
		}
		
		public double getwithdrawals() {
			return withdrawals;
		}
		
		public void withdraw(double amount){  
			if(getBalance() + withdrawals < amount)
			System.out.print("Cannot be done");
		    else
			return super.withdraw(amount);
		}
		
		private double getBalance() {
			return 0;
		}

		public String toString(){
			return super.toString();
		}
}
