package GradeAnalyzer;

import javax.swing.JOptionPane;
import java.util.ArrayList;

public class GradeAnalyzerTester {
	public static void main(String[] args)
	{
		GradeAnalyzer G = new GradeAnalyzer();
		String input = "";
		ArrayList<String> s = new ArrayList<String>();
	    
	    	while(true){
		    	input = JOptionPane.showInputDialog(null," please input the grades�G ");
		    	
		    	if(input.equalsIgnoreCase("q")==true || input.equalsIgnoreCase("Q")==true){
		    		break;
		    	}
		    	else{
		    		s.add(input);
		    		} 
	    	}
		    	
		    	try{
		    		for(int i=0; i<s.size(); i++){
		    		G.addGrade(Double.parseDouble(s.get(i)));
		    		}
		    	}
			    
			    catch(Exception e){
			    	JOptionPane.showMessageDialog(null," please enter valid number�I ");
			    } 
		    	

		    G.analyzeGrades();
		    JOptionPane.showMessageDialog(null,G.toString());
	    	
	}
}

	


	
