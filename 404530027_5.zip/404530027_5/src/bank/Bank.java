package bank;

import java.util.ArrayList;
import java.util.HashMap;

public class Bank {
	
	HashMap<Integer, BankAccount> BankList = new HashMap<Integer, BankAccount>();
	private ArrayList<BankAccount> accounts;
	public Bank()
	{
		accounts = new ArrayList<BankAccount>();
	}

	public void deposit(int accountNumber, double balance) {
		BankAccount tempAccount = (BankAccount) BankList.get(accountNumber);
		try{
			tempAccount.deposit(balance);
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
	}

	public void withdraw(int accountNumber, int balance) {
		BankAccount tempAccount = (BankAccount) BankList.get(accountNumber);
		try{
			tempAccount.withdraw(balance);
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
	
	double getBalance (int accountNumber){
		BankAccount tempAccount = (BankAccount) BankList.get(accountNumber);
		return tempAccount.getBalance();
	}

	public void closeAccount(int accountNumber) {
		BankAccount tempAccount = (BankAccount) BankList.get(accountNumber);
		tempAccount.close();
	}

	public void suspendAccount(int accountNumber) {
		BankAccount tempAccount = (BankAccount) BankList.get(accountNumber);
		tempAccount.suspend();
	}

	public void reOpenAccount(int accountNumber) {
		BankAccount tempAccount = (BankAccount) BankList.get(accountNumber);
		tempAccount.reOpen();
	}
	
	String getAccountStatus(int accountNumber){
		BankAccount tempAccount = (BankAccount) BankList.get(accountNumber);
		return tempAccount.state;
	}
	
	String summarizeAccountTransactions(int accountNumber){
		StringBuffer sb = new StringBuffer();
		BankAccount tempAccount = (BankAccount) BankList.get(accountNumber);
		sb.append("Account #" + accountNumber + "transaction�G\n\n");
		sb.append(tempAccount.getTransations());
		sb.append("End of transaction\n");
		return sb.toString();
	}
	
	public void addCheckingAccount(int accountNumber, double amount){
	    CheckingAccount tempAccount = new CheckingAccount(accountNumber, amount);
	    accounts.add(tempAccount);
	}
	
	public void addSavingsAccount(int accountNumber, double amount, double interestRate){
    	SavingsAccount tempAccount = new SavingsAccount(accountNumber, amount, interestRate);
    	accounts.add(tempAccount);
    }
	
	public void addInterest(int accountNumber){
		BankAccount found = find(accountNumber);
             
	    if(found instanceof SavingsAccount){
	    	found = (SavingsAccount) found;
            found.addInterest(accountNumber);
	    }
    }
	
	private BankAccount find(int accountNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	public void deductFees(int accountNumber){ 
    	BankAccount found = find(accountNumber);
             
        if(found instanceof CheckingAccount){
        	found = (CheckingAccount) found;
            found.deductFees(accountNumber);   
        }
    }
	
	public void transfer(int withdrawAcctNum, int depositAcctNum, double amount){
    	withdraw(withdrawAcctNum, amount);
        deposit(depositAcctNum, amount);
    }
	
	public boolean areEqualAccounts(BankAccount accountNumber1, BankAccount accountNumber2){
    	return accountNumber1.equals(accountNumber2);
	}
	
	public String summarizeAllAccounts(){ 
    	String report = "Bank Account Summary \n \n" + "Account \t Type \t \t Balance \t #Transactions \t \t Status \n";
             
	    for (BankAccount element : accounts){  
	    	report += element.getAccountNumber() + "\t" + "\t ";
                            
            if(element instanceof CheckingAccount){
            	report += "checking";
            }
            else if(element instanceof SavingsAccount){
            	report += "savings";
            }
                 
         report += "\t " + element.getBalance() + "\t" + "\t " + element.retrieveNumberOfTranactions() + "\t" + "\t" + "\t " + element.getStatus() + "\n";
	    }
        return report + "End of Account Summary.";
    }


	
}
