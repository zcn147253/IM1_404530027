package Easter;

public class EasterTester {
      public static void main(String[] args){
    	  
    	  Easter Easterday = new Easter();           
    
    	  System.out.println(Easterday.calculateEaster(2001));
    	  System.out.println(Easterday.calculateEaster(2012));
    	  
      }
}